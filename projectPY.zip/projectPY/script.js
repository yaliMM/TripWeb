document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("register");
    const thankYouMessage = document.getElementById("thankYouMessage");
    const greeting = document.getElementById("greeting");
  
    form.addEventListener("submit", function (event) {
        // מניעת שליחה אוטומטית של הטופס
        event.preventDefault();
  
        // קבלת הערכים מהטופס
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const email = document.getElementById("email").value.trim();
        const identityCard = document.getElementById("pasidentity_card").value.trim();
  
        // בדיקות תקינות
        if (!firstName || !lastName) {
            alert("שם פרטי ושם משפחה הינם שדות חובה.");
            return;
        }
  
        if (!/^\d{10}$/.test(phone)) {
            alert("מספר הטלפון חייב להכיל בדיוק 10 ספרות.");
            return;
        }
  
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert("כתובת האימייל אינה תקינה.");
            return;
        }
  
        if (!/^\d{9}$/.test(identityCard)) {
            alert("תעודת הזהות חייבת להכיל בדיוק 9 ספרות.");
            return;
        }
  
        // אם הכל תקין
        form.reset();

        // הצגת הודעת תודה
         
        greeting.textContent = `תודה שנרשמת, ${firstName}  ${lastName}!, הרשמתך התקבלה`;
        thankYouMessage.style.display = "block";

        // הסתרת הטופס
        form.style.display = "none";
    });
});
